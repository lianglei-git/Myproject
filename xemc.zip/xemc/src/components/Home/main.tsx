import React, { FC, useState } from 'react';
import { Layout, Menu, Button, Dropdown, Tree, Spin, message } from 'antd';
import { blueTheme, goldTheme, grayTheme } from '../../configs/themeCss';
import { useSelector, shallowEqual ,useDispatch } from 'react-redux';
import { cancellationUser } from 'src/store/actions/index';
import MapPage from '../map';
type blendSN = string | number;
interface IProps {
  login: () => void,
  register: () => void,
  changeTheme: (types: number | string) => void
  curmap: number | string
  curtheme: number | string
}
const { Header, Content, Footer, Sider } = Layout;
const MainPage: FC<IProps> = props => {
  const { curmap, curtheme } = props;
  // const [curmap, setCurmap] = useState<blendSN>(0);
  // const [curtheme, setCurtheme] = useState<blendSN>(0);// 0:金色 1:灰色 2:蓝色(暂无)
  const userLoginRespnse: any = useSelector((state: any) => (state.globalReducers.loginResponse), shallowEqual);
  const username: any = useSelector((state: any) => (state.globalReducers.username), shallowEqual);
  const dispatch:any = useDispatch();
  const mapMenu = (
    <Menu theme="dark">
      <Menu.Item className={curmap == 0 ? 'skymap active' : ''}>
        天地图
      </Menu.Item>
    </Menu>
  );
  const changeTheme: (types: string) => void = (types) => {
    if (types == "gold") {
      props.changeTheme(0);
      goldTheme();
    } else if (types == "gray") {
      props.changeTheme(1);
      grayTheme();
    }
  }
  const login = (): void => {
    props.login()
  }

  const themeMenu = () => {

    return (
      <Menu theme="dark" >
        <Menu.Item onClick={() => changeTheme('gold')} className={curtheme == 0 ? 'goldtheme active' : ''} >
          金黄色
          </Menu.Item>
        <Menu.Item onClick={() => changeTheme('gray')} className={curtheme == 1 ? 'graytheme active' : ''}>
          浅灰色
          </Menu.Item>
      </Menu>
    )
  }
  const register = () => {
    props.register()
  }

  const cancellation = () => {
    dispatch(cancellationUser(false))
    message.success("注销成功")
  }
  return (
    <Layout>
      <Header className="site-layout-sub-header-background" >
        <span className="title">
          湘电风资源管理平台
                </span>
        <ul className="fun">
          <li>刷新</li>
          <li>
            <Dropdown overlay={mapMenu} arrow={true}>
              <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                地图
                      </a>
            </Dropdown>
          </li>
          <li>
            <Dropdown overlay={themeMenu} arrow={true}>
              <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                主题
                      </a>
            </Dropdown>
          </li>
          <span> | </span>
          {
            userLoginRespnse.status ?
              <>
                <li >{username}</li>
                <li onClick={() => cancellation()}>注销</li>
              </>
              :
              <>
                <li onClick={() => login()}>登录</li>
                <li onClick={() => register()}>注册</li>
              </>
          }
        </ul>
      </Header>
      <Content style={{ margin: '24px 16px 0' }}>
          <MapPage></MapPage>
      </Content>
      <Footer style={{ textAlign: 'center',color:"#000" }}>Copyright©2019 湘电风能有限公司 湘ICP备17013471号-1 公网安备123456号</Footer>
    </Layout>
  )
}
export default MainPage;