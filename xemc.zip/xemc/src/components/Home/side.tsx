import React, { FC, useState } from 'react';
import { Layout, Menu, Button, Dropdown, Tree, Spin } from 'antd';
import { UploadOutlined, UserOutlined, VideoCameraOutlined, DownOutlined } from '@ant-design/icons';
import { useSelector } from 'react-redux';
import DragModal from 'src/components/Modal/index';
import {
  APPROVAL
} from 'src/configs/common';
import "src/styles/side.less"
interface IProps {
  onSelect: (select: any, info: any) => void
  onCheck: (select: any, info: any) => void
}
const { SubMenu } = Menu;
const { Header, Content, Footer, Sider } = Layout;
const treeData = [
  {
    title: 'parent 1',
    key: '0-0',
    children: [
      {
        title: 'parent 1-0',
        key: '0-0-0',
        disabled: true,
        children: [
          {
            title: 'leaf',
            key: '0-0-0-0',
            disableCheckbox: true,
          },
          {
            title: 'leaf',
            key: '0-0-0-1',

          },
        ],
      },
      {
        title: 'parent 1-1',
        key: '0-0-1',
        children: [{ title: <span style={{ color: '#1890ff' }}>sss</span>, key: '0-0-1-0' }],
      },
    ],
  },
];
const Side: FC<IProps> = props => {
  const globalimage = useSelector<any, any>(({ globalReducers }) => globalReducers.globalImages);
  const [openkeys, setOpenkeys] = useState("sub1");
  const [approvalTitle, setApprovalTitle] = useState("校对、审批数据");
  const [approvalVisible, setApprovalVisible] = useState(false);
  const onSelect = (selectedKeys: any, info: any) => {
    props.onSelect(selectedKeys, info);
  };
  const onCheck = (checkedKeys: any, info: any) => {
    props.onCheck(checkedKeys, info);
  };
  const openchanges = (e: any) => {
    if (e.length >= 1) {
      setOpenkeys(e[e.length - 1])
    }
  }
  const approvalUser = () => {
    console.log("审批用户")
    setApprovalVisible(true)
  }
  const handleCancel = () => {
    setApprovalVisible(false)
  }
  return (
    <>
      <Sider
        breakpoint="lg"
        collapsedWidth="0"
        onBreakpoint={broken => {
          console.log(broken);
        }}
        onCollapse={(collapsed, type) => {
          console.log(collapsed, type);
        }}
      >
        {/* <button onClick={() => this.props.sideAxiosPost({name:"effect successd"})}>改变loading</button> */}
        <div className="xemc_wrp_logo">
          <img src={globalimage.logo} alt="" />
        </div>
        <Menu theme="dark" mode="inline" className="inline" defaultOpenKeys={[openkeys]} openKeys={[openkeys]} onOpenChange={openchanges}>
          <SubMenu
            key="sub1"
            title={
              <span>
                <em id="backgroundImageIcons"  style={{ backgroundImage: `url(${globalimage.projectPublish})`}}></em>
                <span>项目</span>
              </span>
            }
          >
            <>
              <Tree
                selectable={true}
                checkable
                defaultExpandedKeys={['0-0-0', '0-0-1']}
                defaultSelectedKeys={['0-0-0', '0-0-1']}
                defaultCheckedKeys={['0-0-0', '0-0-1']}
                onSelect={onSelect}
                onCheck={onCheck}
                treeData={treeData}
              />
            </>
          </SubMenu>
          <SubMenu
            key="sub2"
            title={
              <span>
                <em id="backgroundImageIcons"  style={{ backgroundImage: `url(${globalimage.projectDatabase})`}}></em>
                <span>未入库测风塔</span>
              </span>
            }
          >
            <>
              <Tree
                selectable={true}
                checkable
                defaultExpandedKeys={['0-0-0', '0-0-1']}
                defaultSelectedKeys={['0-0-0', '0-0-1']}
                defaultCheckedKeys={['0-0-0', '0-0-1']}
                onSelect={onSelect}
                onCheck={onCheck}
                treeData={treeData}
              />
            </>
          </SubMenu>
        </Menu>
        <Menu theme="dark" mode="vertical" className="vertical">
          <SubMenu key="sub3" icon={<em id="backgroundImageIcons" className="backgroundiconsapproval"  style={{ backgroundImage: `url(${globalimage.turbineDatabase})`}}></em>} title="数据库">
            <Menu.Item key="1">项目数据库</Menu.Item>
            <Menu.Item key="2">气象数据库</Menu.Item>
            <Menu.Item key="3">风机数据库</Menu.Item>
          </SubMenu>
          <SubMenu key="sub4" icon={<em  className="backgroundiconsapproval"  style={{ backgroundImage: `url(${globalimage.approve})`,width:"24px",height:"24px"}}></em>} title="校对、审批" className="approveNavButton">
            <Menu.Item key="4" >校对数据</Menu.Item>
            <Menu.Item key="5" className="sub4bottom" style={{ borderBottom: "1px solid #ccc" }}>审批数据</Menu.Item>
            <Menu.Item key="6" onClick={approvalUser}>审批用户</Menu.Item>
            <Menu.Item key="7">用户管理</Menu.Item>
            <Menu.Item key="8">责任人变更</Menu.Item>
          </SubMenu>
        </Menu>
      </Sider>
      <DragModal
        title={approvalTitle}
        mainType={APPROVAL}
        footerType={APPROVAL}
        visible={approvalVisible}
        modalWidth={800}
        isDrag={true}
        handleCancel={handleCancel}
      ></DragModal>

    </>
  )
}


export default Side;