import React, { FC, useEffect } from 'react';
// import 'cesium-tdt'

const Map: FC<any> = props => {
  useEffect(() => {
    console.log((window as any).Cesium)
    // new (window as any).Cesium.Map('cesiumContainer', {
    //   shouldAnimate: true,
    //   selectionIndicator: true,
    //   infoBox: false
    // });
    console.log(123123)
  }, [])
  return (
    <div id="cesiumContainer">
      地图
    </div>
  )

}


export default Map;