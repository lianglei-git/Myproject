
import React, { Component, Fragment } from 'react';
import { DragModalInterfaces } from 'src/interfaces/dragmodal';
import { Modal, message } from 'antd';
import FooterModal from './footer';
import MainModal from './main';
import {
  LOGIN,
  REGISTER,
  RETRIEVEPASSWORD,
  TIPS
} from 'src/configs/common';
import Cookie from 'js-cookie';
import 'src/styles/dragmodal.less';
import { getToken } from 'src/utils/common';
import { threadId } from 'worker_threads';

export default class DragModal extends Component<DragModalInterfaces.IExampleProps, DragModalInterfaces.IExampleState> {
  constructor(props: DragModalInterfaces.IExampleProps) {
    super(props);

  }
  public state = {
    dragging: false,
    preX: "0",
    preY: "0",
    token: null,
    isUpdate: true
  }

  private dragMousrDown(modalDragEl: HTMLElement, modalclientEl: HTMLElement) {
    modalDragEl.onselectstart = () => {
      return false;
    }
    modalDragEl.onmousedown = (e) => {
      this.setState({
        dragging: true,
      })
      var ev = e;
      var x1 = ev.clientX;
      var y1 = ev.clientY;
      var l = modalclientEl.offsetLeft;
      var t = modalclientEl.offsetTop;
      document.onmousemove = (e) => {
        if (this.state.dragging === false) return;
        var ev = e;
        var x2 = ev.clientX;
        var y2 = ev.clientY;
        var x = x2 - x1;
        var y = y2 - y1;
        var lt = y + t;
        var ls = x + l;
        modalclientEl.style.left = ls + 'px';
        modalclientEl.style.top = lt + 'px';
                console.log(this.state.preX,this.state.preY)
      }
    }

    document.onmouseup = (e) => {
      document.onmousemove = null;
      document.onmousedown = null;
      this.setState({
        dragging: false
      })
    }
  }
  static getDerivedStateFromProps(props: any, state: any) {
    if (getToken()) {
      return {
        token: JSON.parse((getToken() as any))
      }
    } else {
      return null
    }


  }
  componentDidUpdate() {
    if (this.props.visible && this.state.isUpdate) {
      this.setState({
        isUpdate: false
      })
      let flag = (this.state.token != null && (this.state.token as any)?.token) || (this.props.mainType == LOGIN || this.props.mainType == REGISTER || this.props.mainType == RETRIEVEPASSWORD)
      let type = flag ? this.props.mainType : TIPS;
      let width: any = flag ? this.props.modalWidth : 200;
      setTimeout(() => {
        const modalDragEl = (document.getElementsByClassName(`${type}_modalDrag`) as any)[0].querySelector('.ant-modal-header');
        const modalclientEl = (document.getElementsByClassName(`${type}_modalDrag`) as any)[0].querySelector('.getOffsetLeft');
        console.log(modalDragEl, modalclientEl)
        this.dragMousrDown(modalDragEl, modalclientEl)
        this.setState({
          preX: `calc( 50% - ${~~(width / 2)}px)`,
          preY: `calc( 50% - ${~~(modalclientEl.offsetHeight / 2)}px)`
        })
      })
    }
  }
  componentWillUnmount() {
    this.setState({
      isUpdate: true
    });
  }
  // static getDerivedStateFromProps(nextProps: DragModalInterfaces.IExampleProps, prevState: DragModalInterfaces.IExampleState) {
  //   console.log(nextProps, prevState)
  //   if (nextProps.visible) {
  //     setTimeout(() => {
  //       const modalDragEl = (document.getElementsByClassName('_modalDrag') as any)[0].querySelector('.ant-modal-header');
  //     })
  //      return {
  //         preX:200
  //       }
  //   }
  //   return null;
  // }

  handleCancel(e: any) {
    this.setState({
      isUpdate: true
    });
    this.props.handleCancel(e);
  }
  render() {
    let flag = (this.state.token != null && (this.state.token as any)?.token) || (this.props.mainType == LOGIN || this.props.mainType == REGISTER || this.props.mainType == RETRIEVEPASSWORD);
    return (
      <Fragment>
        {
          flag ?
            <Modal
              style={{ margin: 0, left: `${this.state.preX}`, top: `${this.state.preY}` }}
              className="getOffsetLeft"
              wrapClassName={`${this.props.mainType}_modalDrag`}
              onCancel={(e) => this.handleCancel(e)}
              title={this.props.title}
              visible={this.props.visible}
              maskClosable={false}
              mask={false}
              width={this.props.modalWidth || 520}
              destroyOnClose={true}
              footer={
                <FooterModal types={this.props.footerType} handleCancel={this.handleCancel.bind(this)} />
              }
            >
              <MainModal types={this.props.mainType}></MainModal>
            </Modal>
            :
            <Modal
              style={{ margin: 0, left: `${this.state.preX}`, top: `${this.state.preY}` }}
              className="getOffsetLeft"
              wrapClassName={`${TIPS}_modalDrag`}
              onCancel={(e) => this.handleCancel(e)}
              title={"提示"}
              visible={this.props.visible}
              maskClosable={false}
              mask={false}
              width={200}
              destroyOnClose={true}
              forceRender={true}
              footer={
                <FooterModal types={TIPS} handleCancel={this.handleCancel.bind(this)} />
              }
            >
              <MainModal types={TIPS} tips={"请先登录用户!"}></MainModal>
            </Modal>
        }




      </Fragment>
    )
  }
}
