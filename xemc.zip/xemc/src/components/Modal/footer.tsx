import React, { Component, useEffect, useRef, useState, FC, Fragment } from 'react';
import { connect, useSelector, useStore, useDispatch, shallowEqual } from 'react-redux';
import { Button } from 'antd';
import {
  LOGIN,
  REGISTER,
  RETRIEVEPASSWORD,
  APPROVAL,
  TIPS,
} from 'src/configs/common';
import { DragModalInterfaces } from 'src/interfaces/dragmodal';
// import { LOGINPOST, REGISTERPOST, LOGINPOSTWATCH } from 'src/store/types/index';
import { loginPostResponse, registerPostResponse } from 'src/store/thunk/user';
import { message } from 'antd';
import { setToken } from 'src/utils/common';

interface renderState {
  type: string | symbol
  render: any;
}
const FooterModal: FC<DragModalInterfaces.ModalFooterProps> = ({ types, handleCancel }) => {
  const store = useStore()
  const dispatch: any = useDispatch();
  const users: any = useSelector((state: any) => state.globalReducers, shallowEqual);
  const registerdata: any = useSelector((state: any) => {
    return state.globalReducers.register
  }, shallowEqual);
  const login = () => {
    dispatch(loginPostResponse({ username: users.username, password: users.password })).then((data: any) => {
      if (data.status) {
        setToken({ token: data.token, cnName: data.user.cnName });
        message.success(data.msg);
        handleCancel({})
      } else {
        message.error(data.msg)
      }
    });
  }
  const register = () => {
    var reg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
    console.log(registerdata.password, registerdata.repeatPassword)
    if (registerdata.password !== registerdata.repeatPassword) {
      message.error('两次密码不一致')
    } else if (!reg.test(registerdata.email)) {
      message.error('邮箱格式错误')
    } else {
      dispatch(registerPostResponse(registerdata)).then((res: any) => {
        if (res.status) {
          message.success("注册成功，请您登录");
          handleCancel({})
        } else {
          message.error(res.msg)
        }
      })
    }

  }
  // const [_r, s_r] = useState<renderState[]>([
  //   {
  //     type: LOGIN,
  //     render:()=>(<><Button key="1" type="primary" shape="round" size="small" onClick={function(){console.log(users)}}> 登录</Button> <Button key="2" type="primary" shape="round" size="small" onClick={handleCancel}> 退出</Button></>)
  //   },
  //   {
  //     type: REGISTER,
  //     render: () => [<Button key="1" type="primary" shape="round" size="small"> 注册</Button>, <Button key="2" type="primary" shape="round" size="small" onClick={handleCancel}> 退出</Button>]
  //   },
  //   {
  //     type: RETRIEVEPASSWORD,
  //     render: () => [<Button key="1" type="primary" shape="round" size="small"> 确定</Button>]
  //   },
  // ])

  // const renderFooter = () => {
  //   return( _r[_r.findIndex((_t) => _t.type == types)].render());
  // }

  return (
    <div className="footerModal">
      {
        (() => {
          switch (types) {
            case LOGIN:
              return (
                <><Button key="1" type="primary" shape="round" size="small" onClick={login}> 登录</Button> <Button key="2" type="primary" shape="round" size="small" onClick={handleCancel}> 退出</Button></>
              )
            case REGISTER:
              return (
                <>
                  <Button key="1" type="primary" shape="round" size="small" onClick={register}> 注册</Button> <Button key="2" type="primary" shape="round" size="small" onClick={handleCancel}> 退出</Button>
                </>
              )
            case RETRIEVEPASSWORD:
              return (
                <>
                  <Button key="1" type="primary" shape="round" size="small" onClick={handleCancel}> 确定</Button>
                </>
              )
            case APPROVAL:
              return (
                <>
                  <Button key="1" type="primary" shape="round" size="small" onClick={handleCancel}>取消</Button>
                </>
              )
            case TIPS:
              return (
                <>
                  <Button key="1" type="primary" shape="round" size="small" onClick={handleCancel}>OK</Button>
                </>
              )
            default:
              return <div></div>;
          }
        })()
      }
    </div>
  )
}
export default FooterModal;