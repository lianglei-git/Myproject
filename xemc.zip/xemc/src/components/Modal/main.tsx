import React, { useState, FC } from 'react';
import DragModal from 'src/components/Modal/index';
import Login from 'src/components/ModalCommon/Login';
import Register from 'src/components/ModalCommon/Register';
import Approval from 'src/components/ModalCommon/Approval'
import {
  LOGIN,
  REGISTER,
  RETRIEVEPASSWORD,
  APPROVAL,
  TIPS
} from 'src/configs/common';

interface renderState {
  type: string | symbol
  render: any;
}
const MainModal: FC<any> = props => {
  const [visible, setvi] = useState(false);
  const { types } = props;
  const [maindata] = useState<renderState[]>([
    {
      type: LOGIN,
      render: (<Login></Login>)
    },
    {
      type: REGISTER,
      render: (<Register></Register>)
    },
    {
      type: APPROVAL,
      render: (<Approval></Approval>)
    },
    {
      type: TIPS ,  // 只有类型为TIPS 才有tips参数
      render: (<span>{props.tips}</span>)
    }
  ])
  const handleCancel = () => {
    setvi(false)
  }
  const chn = () => {
    setvi(true)
  }
  const renderMain = () => {
    let data = maindata[maindata.findIndex((_t) => _t.type == types)];
    return data && data != null && data.render;
  }

  return (
    <>
      {/* <button onClick={chn} >再次弹出</button> */}
      {/* <DragModal
          title={'二级测试'}
          mainType={'table'}
          footerType={'table'}
          visible={visible}
          modalWidth={600}
          isDrag={true}
          handleCancel={handleCancel}
        ></DragModal> */}
      {renderMain()}
    </>
  )
}



export default MainModal;