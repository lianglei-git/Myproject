import React, { useState, FC } from 'react';
import { Tabs, Pagination  } from 'antd';
import { useSelector } from 'react-redux';
import 'src/styles/approval.less';
const { TabPane } = Tabs;

const dataSource = [
  {
    key: '1',
    name: '胡彦斌',
    age: 32,
    address: '西湖区湖底公园1号',
  },
  {
    key: '2',
    name: '胡彦祖',
    age: 42,
    address: '西湖区湖底公园1号',
  },
];

const columns = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '年龄',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: '住址',
    dataIndex: 'address',
    key: 'address',
  },
];

const Approval: FC<any> = (props) => {
  const [activeKey, setActiveKey] = useState("1");
  const globalimage = useSelector<any, any>(({ globalReducers }) => globalReducers.globalImages);
  const [navTitle] = useState([
    {
      title: "校对气象数据",
      idx: 0,
      render:() => (<>anc</>)
    },
    {
      title: "校对项目数据",
      idx: 1,
      render:() => (<>anc</>)
    },
    {
      title: "审批气象数据",
      idx: 2,
      render:() => (<>anc</>)
    },
    {
      title: "审批项目数据",
      idx: 3,
      render:() => (<>anc</>)
    },
    {
      title: "审批用户",
      idx: 4,
      render: (_t: any) => (<>
        <main className="main">
          {_t.title}
          {console.log(123123)}
          
          <div className="filter"></div>
        </main>
        <footer>
          <div className="icons">
            <button title="同意" style={{ backgroundImage: `url(${globalimage.agree})` }}></button>
            <button title="不同意" style={{ backgroundImage: `url(${globalimage.restore})` }}></button>
            <button title="刷新" style={{ backgroundImage: `url(${globalimage.flush})` }}></button>
            <button title="导出" style={{ backgroundImage: `url(${globalimage.export})` }}></button>
          </div>
          <Pagination simple defaultCurrent={2} total={50} />
        </footer>
      </>)
    }
  ])
  const callback = (key: any) => {
    setActiveKey(key)
  }
  return (
    <div className="approval">
      <Tabs onChange={callback} type="card" activeKey={activeKey}>
        {
          navTitle.map((_t:any) => {
            return (
              <TabPane tab={_t.title} key={_t.idx}>
                <div className="table">
                  {_t?.render(_t)}
                </div>

              </TabPane>
            )
          })
        }
      </Tabs>
    </div>
  )
}

export default Approval;