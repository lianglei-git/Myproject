import React, { FC, useState, useReducer } from 'react';
import { useSelector,useDispatch} from 'react-redux';
import { saveUserorPass } from '../../store/actions/index';
import { modelCommon } from "src/interfaces/modelCommon";
import 'src/styles/login.less'
const LoginMain: FC<modelCommon.LoginTypes> = (props) => {

  const [user, setUser] = useState<string | number>('');
  const [password, setPassword] = useState<string | number>('');
  const dispatch = useDispatch();
  const changeUser = (e: any) => {
    setUser(e.target.value);
    dispatch(saveUserorPass({ username: e.target.value, password: password }))

  }
  const changePassword = (e: any) => {
    setPassword(e.target.value);
    dispatch(saveUserorPass({username: user, password: e.target.value }))
    
  }
  const forgetPassword = () => {
    console.log('忘记密码', props)
  }
  return (
    <>
      <div className="loginmain">
        <p><span>用户名</span> <input type="text" value={user} onChange={changeUser} placeholder="请输入用户名" /></p>
        <p><span>密码</span> <input type="password" value={password} onChange={changePassword} placeholder="请输入登录密码" /></p>
        <a onClick={forgetPassword}>忘记密码?</a>
      </div>
    </>
  )
}


export default LoginMain