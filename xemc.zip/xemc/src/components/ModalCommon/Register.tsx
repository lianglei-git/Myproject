import React, { FC, useState } from 'react';
import { Select } from 'antd';
import { save_registerData } from '../../store/actions/index';
import 'src/styles/register.less';
import { useDispatch } from 'react-redux';
const { Option } = Select;
interface Iprops {

}
const RegisterPage: FC<Iprops> = (props) => {
  const [regdata, setRegdata] = useState<any>({
    name: "",
    email: "",
    cnName: "",
    password: "",
    repeatPassword:"",
    userType: "0"
  });
  const dispatch = useDispatch();
  const handleUserChange = (e: any) => {
    let copy = { ...regdata, userType: e };
    setRegdata(copy);
   dispatch(save_registerData(copy));
  }
  const changeRegister = (type: string, e: any) => {
    // 
    let copy = {...regdata,[type]:type == 'name' ? e.target.value.replace(/[^\w\.\/]/ig,'') : e.target.value}
    setRegdata(copy);
    dispatch(save_registerData(copy));
  }
  return (
    <div className="register">
      <div className="tips">
        <ul>
          <li>用户名</li>
          <li>中文名</li>
          <li>密码</li>
          <li>重复密码</li>
          <li>邮箱</li>
          <li>用户级别</li>
          {/* <li>审批人</li> */}
        </ul>
      </div>
      <div className="inputs">
        <div>
          <input type="text" placeholder="请设置用户名"  value={regdata.name} onChange={(e) => changeRegister('name',e)}/>
          <input type="text" placeholder="请设置中文名" value={regdata.cnName} onChange={(e) => changeRegister('cnName',e)}/>
          <input type="password" placeholder="请设置登录密码"  value={regdata.password} onChange={(e) => changeRegister('password',e)}/>
          <input type="password" placeholder="再次输入登录密码" value={regdata.repeatPassword} onChange={(e) => changeRegister('repeatPassword',e)}/>
          <input type="text" placeholder="请设置邮箱" value={regdata.email} onChange={(e) => changeRegister('email',e)}/>
              <Select defaultValue={regdata.userType} style={{ width: 120 }} onChange={handleUserChange}>
                <Option value="0">公共用户</Option>
                <Option value="1">员工</Option>
                <Option value="2">主管</Option>
                {/* <Option value="4">主任</Option> */}
              </Select>
                  {/* <Select defaultValue="1" style={{ width: 120 }} onChange={handleUserChange}>
                    <Option value="1">胡钦</Option>
                  </Select> */}
        </div>
      </div>
    </div>
  )
}


export default RegisterPage;