import React, { useState, FC } from 'react';

interface FilterTableNavTypes {
  type:string
}
const FilterTableNav:FC<FilterTableNavTypes> = (props) => {
  return (
    <div className="filterComponent">
      
      </div>
    )
}

export default FilterTableNav;