
export namespace DragModalInterfaces {
  type objtype = { [propname: string]: any }
  export interface IExampleProps {
    /**
     * @description: 仅注释
     * @param {
     * title:modal的标题
     * mainType：主要内容类型
     * footerType：脚部类型
     * visible：modal的展示开关
     * modalWidth：modal的宽度
     * isDrag：是否可以拖拽
     * handleCancel：取消的fn
     * } 
     * @author: 麻雀
     */    
    title: string    
    mainType: string | number
    footerType: string | symbol | number
    mainData?: any[] | objtype // 还有很多 未定义 例 输入、普通、表格、画布
    footerData?: any[] | objtype
    visible: boolean
    handleCancel:(e:any) => void
    modalWidth: number | string
    isDrag : boolean 
  }
  export interface IExampleState extends objtype {
    // lockList: Array<string | number>
    dragging: boolean
    preX:string | number
    preY: string | number
    token:object | null
  }

  export interface ModalFooterProps {
    types: string | symbol | number
    handleCancel: (e: any) => void
  }
}

