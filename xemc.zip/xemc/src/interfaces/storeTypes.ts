
import { gray } from 'src/configs/themeImages';
export namespace StoreGlobalTypes {
  export interface GlobalTypes {
    globalLoading: boolean
    username: string | null
    password: string | null
    globalImages: typeof gray
    loginResponse:Object | any
    user:Object | any
    register:Object  | any
  }
}