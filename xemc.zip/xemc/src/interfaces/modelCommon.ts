
export  namespace modelCommon {
  export interface LoginTypes {
    
  }
}