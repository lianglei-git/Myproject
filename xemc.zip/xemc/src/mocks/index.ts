
import Mock from 'mockjs';
let Random = Mock.Random;
const numebr = Random.integer(18, 30);
const county = Random.county(true);
let names = Random.cname();

// Mock.mock('http://192.168.10.185:8081/windey/system/loginProcessing', 'post', { 'data': [names, county, numebr] });
Mock.mock('/data/api/user/login', 'post', { 'data': {status:'登录成功',} });



