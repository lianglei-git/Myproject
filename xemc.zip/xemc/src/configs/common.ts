/*
 * @Description: 
 * @Version: 2.0
 * @Autor: 
 * @Date: 2020-07-28 10:26:11
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-26 11:23:52
 */


let GLOBALCLASSNAME:string = 'blue_';
const cookieExpires: number = 1;




// modalTypes 

const LOGIN = 'login';
const REGISTER = 'register';
const RETRIEVEPASSWORD = 'retrieve_password';
const APPROVAL = 'approval';
const TIPS = 'tips'
export {
  GLOBALCLASSNAME,
  cookieExpires,
  LOGIN,
  REGISTER,
  RETRIEVEPASSWORD,
  APPROVAL,
  TIPS
}