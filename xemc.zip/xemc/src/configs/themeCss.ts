/*
 * @Description: 切换主题
 * @Version: 2.0
 * @Autor: 麻雀
 * @Date: 2020-07-24 10:44:08
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-07-24 11:05:30
 */ 



export const blueTheme: () => void = (): void => {
  (window as any).less.modifyVars(
    {
      '@primary-color': '#616464',
      '@global-color': '#cdb765',
      '@hover-color': '#fff',
      '@background-global':'#3d3e3e'
    }).then(() => {
      console.log('success')
    }).catch((err: any) => {
      console.log(err)
    })
}


export const goldTheme: () => void = (): void => {
  (window as any).less.modifyVars(
    {
      '@primary-color': '#616464',
      '@global-color': '#cdb765',
      '@hover-color': '#fff',
      '@background-global': '#3d3e3e',
      '@text-color': '#fff',
      '@background-sub':'#323232',
      
    }).then(() => {
      console.log('success')
    }).catch((err: any) => {
      console.log(err)
    })
}


export const grayTheme: () => void = (): void => {
  (window as any).less.modifyVars(
    {
      '@primary-color': '#908a8a',
      '@global-color': '#000',
      '@hover-color': '#fff',
      '@background-global': '#cdcdcd',
      '@text-color': '#000',
      '@background-sub':'#dedede',
    }).then(() => {
      console.log('success')
    }).catch((err: any) => {
      console.log(err)
    })
}