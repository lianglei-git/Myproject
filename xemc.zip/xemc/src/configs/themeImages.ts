/*
 * @Description: 
 * @Version: 2.0
 * @Autor: 
 * @Date: 2020-07-28 10:26:11
 * @LastEditors: 
 * @LastEditTime: 2020-08-28 14:25:18
 */

import blue_logo from '@blue/images/logo.png'; 
import gold_logo from '@gold/images/logo.png';
import gray_logo from '@gray/images/logo.png';
import { GLOBALCLASSNAME } from './common';

let logo:any = null;
if (GLOBALCLASSNAME == 'blue_') {
  logo = blue_logo;
} else if (GLOBALCLASSNAME == 'gray_') {
  logo = gray_logo;
} else {
  logo = gold_logo;
}

const blue = {
  logo: require("@blue/images/logo.png"),
  agree: require("@blue/images/agree.png"),
  restore: require("@blue/images/restore.png"),
  flush:require("@blue/images/flush.png"),
  export:require("@gray/images/export.png"), // 没有
}
const gray = {
  logo: require("@gray/images/logo.png"),
  agree: require("@gray/images/agree.png"),
  restore: require("@gray/images/restore.png"),
  flush:require("@gray/images/flush.png"),
  export:require("@gray/images/export.png"),
  projectPublish:require("@gray/images/projectPublish.png"),
  projectDatabase:require("@gray/images/projectDatabase.png"),
  turbineDatabase:require("@gray/images/turbineDatabase.png"),
  approve:require("@gray/images/approve.png"),

}
const gold = {
  logo: require("@gold/images/logo.png"),
  agree: require("@gold/images/agree.png"),
  restore: require("@gold/images/restore.png"),
  flush:require("@gold/images/flush.png"),
  export:require("@gold/images/export.png"),
  projectPublish:require("@gold/images/projectPublish.png"),
  projectDatabase:require("@gold/images/projectDatabase.png"),
  turbineDatabase:require("@gold/images/turbineDatabase.png"),
  approve:require("@gold/images/approve.png"),

}




export {
  blue,
  gold,
  gray,
  logo
}