import { post } from '../../utils/http';
 const getsidetreedata: (data: any) => Promise<any> = async (data: any):Promise<any> => {
   console.log(data.data,'我执行了吗')
   return await post('/sidetree', data).then((a: any) => {
        console.log(a)
      } )
}

const project = {
  getsidetreedata
}

export default project;