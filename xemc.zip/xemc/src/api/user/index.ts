

import { post } from '../../utils/http';
const loginHttp: (data: { username: string | number, password: string | number } | any) => Promise<any> = async (data): Promise<any> => {
  return await post('/system/loginProcessing', data).then((res: any) => {
    return res;
  })
} 

const registerHttp: (data: { username: string | number, password: string | number } | any) => Promise<any> = async (data): Promise<any> => {
  return await post('/system/sendEmailForRegister', data).then((res: any) => {
    return res;
  })
} 

const user = {
  loginHttp,
  registerHttp
}

export default user;