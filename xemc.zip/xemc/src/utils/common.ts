/*
 * @Description: 
 * @Version: 2.0
 * @Autor: 
 * @Date: 2020-08-01 18:55:29
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-26 11:55:58
 */
import Cookie from 'js-cookie';
import { cookieExpires } from '../configs/common';

const TOKEN_KEY: string = "token";
const setToken = (token: object): void => {
  Cookie.set(TOKEN_KEY, JSON.stringify(token), {expires:cookieExpires || 1})
}


const getToken = (): string | boolean | object | JSON =>{
  const token = Cookie.get(TOKEN_KEY);
  return token ? token : false
}
const removeToken = (): boolean | void => {
  const token: any = Cookie.get(TOKEN_KEY);
  if (token) {
      Cookie.remove(TOKEN_KEY);
      return true;
  } else {
      return false
  }
}

export {
  setToken,
  getToken,
  removeToken
}