
import axios, { AxiosRequestConfig } from 'axios';
import qs from 'qs';
import {  getToken, removeToken } from './common';
import { message } from 'antd';
import store from '../store/index';
import { GLOBALLOADINGFLAGTYPES } from '../store/types/index';
const service = axios.create({
  baseURL: process.env.REACT_APP_BASE_API,
  timeout: 20000,
  withCredentials: true,
  headers: {
    'X-Requested-With': 'XMLHttpRequest',
    'Content-Type': 'application/x-www-form-urlencoded',
  }
})
service.interceptors.request.use((config: AxiosRequestConfig) => {
  const token = getToken();
  store.dispatch({ type: GLOBALLOADINGFLAGTYPES, flag: true });
  token && (config.headers.Authorization = token);
  return config;
}, (error: Error) => {
  store.dispatch({ type: GLOBALLOADINGFLAGTYPES, flag: false });
  message.error('请求超时');
  return Promise.reject(error)
})


service.interceptors.response.use((response) => {
  store.dispatch({ type: GLOBALLOADINGFLAGTYPES, flag: false });
  if (response.status == 200) {
    return Promise.resolve(response);
  } else {
    return Promise.reject(response)
  }
}, error => {
  store.dispatch({ type: GLOBALLOADINGFLAGTYPES, flag: false });
  if (error.message.includes('timeout')) {
    message.error('请求超时，请检查网络再重新连接',);
    return Promise.reject('请求超时，请检查网络再重新连接');
  } else if (error && error.response?.status) {
    switch (error.response.status) {
      case 403:
        message.error('登录过期，请重新登录');
        removeToken();
        break;
      case 404:
        message.error('网络请求不存在');
        // setTimeout(() => {
        //     router.replace({
        //         path: '/404',
        //         query: {
        //             redirect: router.currentRoute.fullPath
        //         }
        //     });
        // }, 1000);
        break;
      default:
        try {
          message.error(error.response.data.message || "用户信息已过期，请重新登录");

        } catch (error) {
          return Promise.reject(error.response);
        }

    }
  } else {
    message.error('请检查网络重新连接！',);
    return Promise.reject('请检查网络重新连接!');
  }
})




// 请求方式的配置

export const post = (url: any, data?: any) => {  //  post
  return new Promise((resolve: any, reject: any) => {
      service({
          method: 'post',
          url,
          data: qs.stringify(data),
      }).then(
        res => {
              return resolve(res.data);
          }
      ).catch(err => {
          return reject(err)
      })
  })

}
export const get = (url: any, params?: any) => {  // get
  return new Promise((resolve: any, reject: any) => {
      service({
          method: 'get',
          url,
          params, // get 请求时带的参数
      }).then(
          res => {
              return resolve(res.data);
          }).catch(
              err => {
                  return reject(err)
              })
  })

}
