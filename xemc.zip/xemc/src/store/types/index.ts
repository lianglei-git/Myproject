
export const USERTYPES = Symbol('user_types');
export const SIDEPROJECTSAVETYPES = Symbol('sideprojectsave_types');
export const SIDEPROJECTDISPATCHTYPES = Symbol('sideprojectdispatch_types');
export const GLOBALLOADINGFLAGTYPES = Symbol('globalloadingflag_types');
export const SAVEUSERORPASSWORD = Symbol('save_UserOrPassword');
export const LOGINPOST = Symbol('login');
export const LOGINPOSTWATCH = Symbol('login_watch');
export const REGISTERPOST = Symbol('register');
export const REGISTERPOSTWATCH = Symbol('register_watch');
export const CHANGEGLOBALIMAGES = Symbol('change globalImages')
export const SAVELOGINRESPONSE = Symbol('save loginResponse')
export const CANCELITATION = Symbol('user canceliation');
export const SAVEREGISTERRESPONSE = Symbol('save registerResponse');
export const SAVEREGISTERDATA = Symbol('save registerdata')
export const SAVEUSERNAME = Symbol('save username')