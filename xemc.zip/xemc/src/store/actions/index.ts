/*
 * @Description: 
 * @Version: 2.0
 * @Autor: 
 * @Date: 2020-08-21 10:41:41
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-26 12:00:02
 */
/**
 * @description: user
 * @author: 
 */

import { SAVEUSERORPASSWORD,SAVEREGISTERDATA, SAVEUSERNAME,SAVEREGISTERRESPONSE, LOGINPOSTWATCH, CHANGEGLOBALIMAGES , SAVELOGINRESPONSE,CANCELITATION} from '../types';
export const save_loginResponse = (payload:any) => ({
    type: SAVELOGINRESPONSE,
    payload
})

export const changeGlobalImages = (type: any) => ({
    type: CHANGEGLOBALIMAGES,
    data: type
})

export const cancellationUser = (flag: boolean) => ({
    type: CANCELITATION,
    flag
})
export const save_registerResponse = (payload: any) => ({
    type: SAVEREGISTERRESPONSE,
    payload
})
export const save_registerData = (data: any) => ({
    type: SAVEREGISTERDATA,
    data
})
export const save_username = (data: any) => ({
    type: SAVEUSERNAME,
    data
})
export const saveUserorPass = (data: any) => ({type:SAVEUSERORPASSWORD,data})

export const loginPostWatch = (data: any) => ({type:LOGINPOSTWATCH,data})

