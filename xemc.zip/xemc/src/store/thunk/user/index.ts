/*
 * @Description: 
 * @Version: 2.0
 * @Autor: 
 * @Date: 2020-08-21 12:49:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-24 14:28:32
 */
import { SAVEUSERORPASSWORD, LOGINPOST, LOGINPOSTWATCH, CHANGEGLOBALIMAGES, SAVELOGINRESPONSE } from '../../types/index'
import { save_loginResponse , save_registerResponse} from '../../actions/index';
import { user } from '../../../api/index';

export const loginPostResponse = (data:any) => {
  return async (dispatch: any) => {
    let res = await user.loginHttp(data);
    dispatch(save_loginResponse(res))
    return res;
  }
}

export const registerPostResponse = (data:any) => {
  return async (dispatch: any) => {
    let res = await user.registerHttp(data);
    dispatch(save_registerResponse(res))
    return res;
  }
}