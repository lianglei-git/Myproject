import { SIDEPROJECTSAVETYPES,SIDEPROJECTDISPATCHTYPES } from '../../types/index';
export const projectReducer = (state = {}, action: any) => {
  switch (action.type) {
    case SIDEPROJECTSAVETYPES:
      console.log('触发到reducers了');
      return Object.assign({}, state);
    default:
      return state;
  }
}


