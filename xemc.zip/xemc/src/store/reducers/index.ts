
import { combineReducers } from 'redux';

import { projectReducer } from './project/index';

import { GLOBALLOADINGFLAGTYPES, SAVEREGISTERDATA , SAVEUSERNAME, SAVEUSERORPASSWORD , SAVEREGISTERRESPONSE, CHANGEGLOBALIMAGES , SAVELOGINRESPONSE, CANCELITATION} from '../types/index';

import { blue, gray, gold } from '../../configs/themeImages';

import { StoreGlobalTypes } from '../../interfaces/storeTypes'


const globalReducers = (state: StoreGlobalTypes.GlobalTypes = { user:{}, globalLoading: false, username: null, password: null,register:{}, globalImages: gold , loginResponse:{status:false}}, action: any) => {
  switch (action.type) {
    case GLOBALLOADINGFLAGTYPES:  // 修改loading
      return Object.assign({}, state, { globalLoading: action.flag });
    case CHANGEGLOBALIMAGES: // 修改全局图片主题类型
        return Object.assign({}, state, { globalImages: action.data == 0 ? gold : (action.data ==1 ? gray : blue)  });
    case SAVEUSERORPASSWORD: // 改变username和password
      return Object.assign({}, state, { username: action.data.username, password: action.data.password });
    case SAVEREGISTERDATA :// 注册数据
      return { ...state , register:action.data};
    case SAVELOGINRESPONSE: // 登录之后的响应数据
      if (action.payload.status) {
         return { ...state , loginResponse:{ status: action.payload.status } ,user:action.payload.user};
      }
      return { ...state ,loginResponse:{status:action.payload.status}};
    case CANCELITATION:
      return { ...state, loginResponse: { status: action.flag } }
    case SAVEREGISTERRESPONSE :
      return { ...state }
    case SAVEUSERNAME:
      return {...state,username:action.data.cnName, loginResponse:action.data.loginResponse}
    default:
      return state;
  }
}

export default combineReducers({ projectReducer, globalReducers });