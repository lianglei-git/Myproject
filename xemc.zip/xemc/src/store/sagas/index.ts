
import {all } from 'redux-saga/effects';
import { actionWatcher } from './project';
// import { loginPostWatch } from './login';

export default function* rootSaga() {
    yield all([actionWatcher()])
}