
import {  put } from 'redux-saga/effects';
// import {CHANGEGLOBALIMAGES} from "../types"
// export function* changeGlobalImages(type: string) {
//   yield put({type:CHANGEGLOBALIMAGES,data:type})
// }