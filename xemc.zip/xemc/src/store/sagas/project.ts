import { call, put, takeEvery } from 'redux-saga/effects';
import { SIDEPROJECTSAVETYPES,SIDEPROJECTDISPATCHTYPES  } from '../types';
import { project } from '../../api/index';

// export default function* 


function* sideProjectTreeDataPost(data: any): any {
  const res =yield call(project.getsidetreedata, data);
  yield put({type:SIDEPROJECTSAVETYPES,data:res})
}

export function* actionWatcher() {
  yield takeEvery(SIDEPROJECTDISPATCHTYPES, sideProjectTreeDataPost);
}


