import { call, put, takeEvery } from 'redux-saga/effects';
// import { SAVELOGINRESPONSE, LOGINPOSTWATCH} from '../types';
// import { user } from '../../api/index';
// function* loginPost(data:any) {
//   let res = yield call(user.loginHttp, data);
//   yield put({ type: SAVELOGINRESPONSE, data: res });
// }

// export function* loginPostWatch() {
//  yield takeEvery(LOGINPOSTWATCH, loginPost) 
// }
