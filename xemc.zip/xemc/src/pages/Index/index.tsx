import * as React from 'react';
import { Layout,Spin } from 'antd';
import { GLOBALCLASSNAME } from '../../configs/common';
import {  SIDEPROJECTDISPATCHTYPES } from '../../store/types/index';
import { connect } from 'react-redux';
import DragModal from 'src/components/Modal/index';
import '../../mocks';
import SidePage from 'src/components/Home/side';
import MainPage from 'src/components/Home/main';
import { changeGlobalImages , save_username} from 'src/store/actions/index';
import { getToken } from 'src/utils/common';
import {
  LOGIN,
  REGISTER,
  RETRIEVEPASSWORD
} from 'src/configs/common';
class Home extends React.Component<any, any> {
  constructor(props: any) {
    super(props)
    this.state = {
      curmap:0,
      curtheme:0,// 0:金色 1:灰色 2:蓝色(暂无)
      modalType:{
        modalMaintype: LOGIN,
        modalFootertype: LOGIN,
        modalTitle: '登录',
        visible: false,
        modalWidth: 300,
        isDrag:true,
      }
    };
  }


  public onSelect = (selectedKeys: any, info: any) => {
    console.log('selected', selectedKeys, info);
  };
  public onCheck = (checkedKeys: any, info: any) => {
    console.log('onCheck', checkedKeys, info);
  };
  public changeTheme = (type: number | string) => {
    this.props.changeGlobalImages(type)
    console.log(type)
      this.setState({
        curtheme : type
      })
  }
  login() {
    this.setState({
      visible:true,
      modalType:{
        modalMaintype: LOGIN,
        modalFootertype: LOGIN,
        modalTitle: '登录',
        visible: true,
        modalWidth: 300,
        isDrag:true,
      }
    })
  }
  handleCancel(e:Event) {
    this.setState({
      modalType:{
        visible:false
      }
    })
  }
  register() {
    this.setState({
      modalType:{
        modalMaintype: REGISTER,
        modalFootertype: REGISTER,
        modalTitle: '注册',
        visible: true,
        modalWidth: 400,
        isDrag:true,
      }
    })
    console.log(this.state.modalType)

  }
  componentDidMount() {
    let tokendata: any = getToken();
    let loginResponse = JSON.parse(JSON.stringify(this.props.loginResponse))
    if (tokendata) {
      tokendata = JSON.parse(tokendata);
      loginResponse.status = true;
      this.props.save_username({cnName:tokendata.cnName,loginResponse})
    }  else {
         this.login()
    }
  }
  public render() {
    return (
      <>
        <Spin spinning={this.props.globalLoading}>
          <div className="main">
            <Layout>
              <SidePage onSelect={this.onSelect.bind(this)} onCheck={this.onCheck.bind(this)} />
              <MainPage curtheme={this.state.curtheme} curmap={this.state.curmap} changeTheme={this.changeTheme.bind(this)} login={this.login.bind(this)} register={this.register.bind(this)}></MainPage>
            </Layout>
          </div>
        </Spin>
        <DragModal
          title={this.state.modalType.modalTitle}
          mainType={this.state.modalType.modalMaintype}
          footerType={this.state.modalType.modalFootertype}
          visible={this.state.modalType.visible}
          modalWidth={this.state.modalType.modalWidth}
          isDrag={this.state.modalType.isDrag}
          handleCancel={this.handleCancel.bind(this)}
        ></DragModal>
      </>
    )
  }
}
const mapStateToProps = (state: any, ownProps: any) => {
  return {
    globalLoading: state.globalReducers.globalLoading,
    loginResponse:state.globalReducers.loginResponse
  }
}

const mapDispatchToProps = (dispatch: any, ownProp: any) => {
  return {
    sideAxiosPost: (data: any) => dispatch({ type: SIDEPROJECTDISPATCHTYPES, data }),
    changeGlobalImages:(type:string | number) => dispatch(changeGlobalImages(type)),
    save_username:(data:object) => dispatch(save_username(data))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);