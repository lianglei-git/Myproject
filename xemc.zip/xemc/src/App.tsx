import React from 'react';
import Home from './pages/Index/index';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store/index';
import './styles/App.less';
import '@assets/css/reset.less';
// Switch, Link, NavLink,
function App() {

  return (
    <Provider store={store}>
      <div className="App">
        <Router >
          <Route path="/*" component={Home}>
          </Route>
        </Router>
      </div>
    </Provider>

  );
}

export default App;
