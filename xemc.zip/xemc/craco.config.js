const CracoLessPlugin = require('craco-less');
const path = require('path');
const pathResolve = pathUrl => path.join(__dirname, pathUrl);
module.exports = {
  plugins: [
    {
      plugin: CracoLessPlugin,
      options: {
        lessLoaderOptions: {
          lessOptions: {
            modifyVars: { "@primary-color":"transparent","@text-color":"whrite"},
            javascriptEnabled: true,
          },
        },
      },
    },
  ],
  babel: {
    plugins: [
      ["@babel/plugin-proposal-decorators", { legacy: true }],
      ['import', { libraryName: 'antd', style: true }],
    ]
  },
  webpack: {
    alias: {
      "@@": pathResolve('.'),
      '@': pathResolve('src'),
      "@images": pathResolve('src/assets/images'),
      "@blue": pathResolve('src/assets/images/blue'),
      "@gray": pathResolve('src/assets/images/gray'),
      "@gold": pathResolve('src/assets/images/gold'),
      '@pages': pathResolve('src/pages'),
      '@store': pathResolve('src/store'),
      '@utils': pathResolve('src/utils'),
      '@assets': pathResolve('src/assets'),
      "@components": pathResolve('src/components')
    }
  }
};



// "paths":{
//   "@@/*": ["./*"],
//   "@/*": ["src/*"],
//   "@assets/*": ["src/assets/*"],
//   "@components/*": ["src/components/*"],
//   "@blue/*": ["src/assets/images/blue/*"],
//   "@gold/*": ["src/assets/images/gold/*"],
//   "@gray/*": ["src/assets/images/gray/*"],
//   "@pages/*": ["src/pages/*"],
//   "@images/*": ["src/assets/images/*"],
//   "@store/*": ["src/store/*"],
//   "@utils/*": ["src/utils/*"]
// },